﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using CIMS.Exceptions;
using CIMS.Entities;
using System.Runtime.Serialization.Formatters.Binary;

namespace CIMS.DAL
{
    public class CarDAL
    {
        public static List<Car> Carlist = new List<Car>();

        public static string FileName = "ListofCars.txt";
        public bool AddCarDAL(Car newcar)
        {
            bool CarAdded = false;
            try
            {
                Carlist.Add(newcar);
                Serialization();
                CarAdded = true;

            }
            catch (SystemException ex)
            {
                throw new CarException(ex.Message);
            }
            return CarAdded;
        }
        public Car SearchCarDAL(string model)
        {
            Deserialization();
            Car carsearch;
            try
            {
                carsearch = Carlist.Find(car => car.Model == model);
            }
            catch (CarException)
            {
                throw;
            }
            return carsearch;
        }

        public bool ModifyCarDAL(Car modifycar)
        {
            Deserialization();
            bool Modified = false;
            try
            {
                for (int i = 0; i < Carlist.Count; i++)
                {
                    if (Carlist[i].Model == modifycar.Model)
                    {
                        Carlist[i].ManufacturerName = modifycar.ManufacturerName;
                        Carlist[i].Mileage = modifycar.Mileage;
                        Carlist[i].price = modifycar.price;
                        Carlist[i].Seat = modifycar.Seat;
                        Carlist[i].BootSpace = modifycar.BootSpace;
                        Carlist[i].AirBagDetails = modifycar.AirBagDetails;
                        Carlist[i].BHP = modifycar.BHP;
                        Carlist[i].Engine = modifycar.Engine;
                        Modified = true;
                        break;
                    }
                }
                Serialization();

            }
            catch (CarException)
            {
                throw;
            }
            return Modified;
        }

        public bool RemoveCarDAL(string modelto)
        {
            //bool removed = false;
            //CarEntities carremove;
            //try
            //{
            //    Carlist.Clear();
            //    Deserialization();

            //    carremove = Carlist.Find(car => car.Model == modelto);
            //    Carlist.Remove(carremove);
            //    removed = true;
            //    Serialization();
            //}
            bool removed = false;
            try
            {
                Carlist.Clear();
                Deserialization();
                Car deleteclist = Carlist.Find(car => car.Model == modelto);
                if (deleteclist != null)
                {
                    Carlist.Remove(deleteclist);
                    removed = true;
                    Serialization();
                }


            }
            catch (CarException)
            {
                throw;
            }
            return removed;
        }

        public List<Car> ShowDAL()
        {
            try
            {
                Deserialization();
                return Carlist;
            }
            catch (CarException)
            {
                throw;
            }
        }
        public void Serialization()
        {
            try
            {
                FileStream fs = new FileStream(FileName, FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, Carlist);
                fs.Close();
                //Carlist.Clear();

            }

            catch (FileNotFoundException ex)

            {

                Console.WriteLine(ex.Message);

            }
            catch (CarException)
            {
                throw;
            }
        }
        public void Deserialization()
        {
            try
            {
                FileStream fs = new FileStream(FileName, FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();

                Carlist.Clear();
                Carlist = bf.Deserialize(fs) as List<Car>;
                fs.Close();


            }

            catch (FileNotFoundException ex)

            {

                Console.WriteLine(ex.Message);

            }
            catch (CarException)
            {
                throw;
            }

        }
    }
}

    

