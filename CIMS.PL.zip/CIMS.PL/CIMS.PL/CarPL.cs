﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIMS.Exceptions;
using CIMS.Entities;
using CIMS.BAL;


namespace CIMS.PL
{
    
        class CarPL
        {
            static void Main(string[] args)
            {
                try
                {
                    int Choice;
                    do
                    {
                        Print();
                        Console.WriteLine("Enter your choice");
                        Choice = Int32.Parse(Console.ReadLine());
                        switch (Choice)
                        {
                            case 1:
                               AddcarPL();
                               break;
                            case 2:
                                ModifycarPL();
                                break;
                            case 3:
                                SearchcarPL();
                                break;
                            case 4:
                                RemovecarPL();
                                break;
                            case 5:
                                ShowallPL();
                                break;
                            case 6:
                                return;
                            default:
                                Console.WriteLine("invalid choice");
                                break;
                        }

                    } while (Choice != -1);
                }
                catch (CarException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public static void AddcarPL()
            {
                Car car = new Car();
                try
                {
                    Console.Clear();
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("                                 Add Car Details                           ");
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter Manufacturer Name");
                    car.ManufacturerName = Console.ReadLine();
                    Console.WriteLine("Enter Car Model");
                    car.Model = Console.ReadLine();
                    Console.WriteLine("Enter Car Type it should be Hatchback or Sedan or SUV");
                    car.Type = Console.ReadLine();
                    Console.WriteLine("Enter Engine");
                    car.Engine = Console.ReadLine();
                    Console.WriteLine("Enter BHP of the car");
                    car.BHP = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Car Transmission either Manual or Automatic");
                    car.Transmission = Console.ReadLine();
                    Console.WriteLine("Enter Mileage of the car");
                    car.Mileage = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the no. of seats of the car");
                    car.Seat = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Airbags details");
                    car.AirBagDetails = Console.ReadLine();
                    Console.WriteLine("Enter BootSpace of the car");
                    car.BootSpace = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Price of the car");
                    car.price = double.Parse(Console.ReadLine());


                    bool added = CarBAL.AddCarBAL(car);
                    if (added)
                        Console.WriteLine("Car Details are added successfully");
                    else
                        Console.WriteLine("Details are not added ");
                }
                catch (CarException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public static void ModifycarPL()
            {
                string model;
                try
                {
                    Console.Clear();
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("                                 Modify Car Details                           ");
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("************************************************************************************");
                   Console.WriteLine("Enter  car Model");
                    model = Console.ReadLine();
                    Car car = CarBAL.SearchCarBAL(model);
                    if (car != null)
                    {
                        Console.WriteLine("Enter Manufacturer Name");
                        car.ManufacturerName = Console.ReadLine();

                        Console.WriteLine("Enter Car Type(Hatchback or Sedan or SUV)");
                        car.Type = Console.ReadLine();
                        Console.WriteLine("Enter Engine");
                        car.Engine = Console.ReadLine();
                        Console.WriteLine("Enter BHP of the car");
                        car.BHP = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Car Transmission (Manual/Automatic)");
                        car.Transmission = Console.ReadLine();
                        Console.WriteLine("Enter Mileage of the car");
                        car.Mileage = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter no. of seats of the car");
                        car.Seat = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Airbags details of the car");
                        car.AirBagDetails = Console.ReadLine();
                        Console.WriteLine("Enter BootSpace of the car");
                        car.BootSpace = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Price of the car");
                        car.price = double.Parse(Console.ReadLine());
                        bool modified = CarBAL.ModifyCarBAL(car);
                        if (modified)
                            Console.WriteLine("Car Details are updated");
                        else
                            Console.WriteLine("Car Details are not updated");
                    }
                    else
                        Console.WriteLine("Model not found");
                }
                catch (CarException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public static void SearchcarPL()
            {
                string model;
                Car car;
                try
                {
                    Console.Clear();
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("                                 Search car Details                         ");
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("Enter  car Model");
                    model = Console.ReadLine();

                    car = CarBAL.SearchCarBAL(model);
                    if (car != null)
                    {
                        Console.WriteLine("Car is found");
                        Console.WriteLine("*****************************************************************************");
                        Console.WriteLine(car.ManufacturerName + "\t" + car.Model + "\t" + car.Type + "\t" + car.price);
                        Console.WriteLine("*****************************************************************************");

                    }
                    else
                        Console.WriteLine("Car not found");

                }
                catch (CarException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            public static void RemovecarPL()
            {
                try
                {
                    string model;
                    Console.Clear();
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("                                 Remove Car Details                           ");
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("Enter  car Model");
                    model = Console.ReadLine();
                    Console.WriteLine(" Are you sure want to delete \t" + model + "\tenter 1 for Yes or 2 for No");
                    int a = int.Parse(Console.ReadLine());
                    switch (a)
                    {
                        case 1:
                            bool removedcar = CarBAL.RemoveCarBAL(model);

                            if (removedcar)
                                Console.WriteLine("Car Details are removed successfully");
                            else
                                Console.WriteLine("Details are not removed as details are not found ");

                            break;
                        case 2:
                            break;
                        default:
                            Console.WriteLine("Invalid choice");
                            break;

                    }
                }
                catch (CarException ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

            public static void ShowallPL()
            {
                List<Car> carlist = new List<Car>();
                try
                {
                    Console.Clear();
                    Console.WriteLine("************************************************************************************");
                    Console.WriteLine("                                 Display All Cars                           ");
                    Console.WriteLine("************************************************************************************");
                    carlist = CarBAL.ShowBAL();

                    Console.WriteLine("*********************************************************************************");
                    Console.WriteLine("ManufacturerName\tModel\tType\tPrice");
                    Console.WriteLine("*********************************************************************************");
                    foreach (Car car in carlist)
                        Console.WriteLine(car.ManufacturerName + "\t" + car.Model + "\t" + car.Type + "\t" + car.price);

                }
                catch (CarException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public static void Print()
            {
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Car Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("1. Add Car ");
                Console.WriteLine("2. Modify car");
                Console.WriteLine("3. Search Car");
                Console.WriteLine("4. Remove car");
                Console.WriteLine("5. Show list");
                Console.WriteLine("6.Exit");
            }
        }
    }

