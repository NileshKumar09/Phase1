﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using CIMS.DAL;
using CIMS.Entities;
using CIMS.Exceptions;


namespace CIMS.BAL
{
    public class CarBAL
    {
        public static List<Car> Carlist = new List<Car>();
        public static bool Validate(Car car)
        {
            bool validate = true;
            try
            {

                if (!(Regex.IsMatch(car.ManufacturerName, @"^[A-Z]{1}[a-z]{2,}$")))
                {
                    validate = false;
                    throw new CarException("Manufacturer name should start with a capital letter");
                }

                for (int i = 0; i < Carlist.Count; i++)
                {
                    for (int j = i + 1; j < Carlist.Count; j++)
                    {
                        if (Carlist[i].Model == Carlist[j].Model)
                        {
                            validate = false;
                            throw new CarException("Model should be unique");
                        }
                    }
                }
                if (car.Type != "Hatchback" && car.Type != "SUV" && car.Type != "Sedan")
                {
                    validate = false;
                    throw new CarException("Type name should be Hatchback or Sedan or SUV");
                }
                if (!(Regex.IsMatch(car.Engine, @"^\d\.\dL$")))
                {
                    validate = false;
                    throw new CarException("Engine name should have 4 characters with 1st and 3rd character should be a number and 2nd should be a'.'and last would be a 'L'");

                }
                if (!(Regex.IsMatch(car.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    throw new CarException("BHP should be a number");
                }
                if (car.Transmission != "Manual" && car.Transmission != "Automatic")
                {
                    validate = false;
                    throw new CarException("Should be either Manual or Automatic");
                }
                if (!(Regex.IsMatch(car.Mileage.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Mileage should be a number");
                }
                if (!(Regex.IsMatch(car.Seat.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("seats should be a number");
                }
                if (!(Regex.IsMatch(car.AirBagDetails, @"^[A-Za-z]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Airbags details should be a string");
                }
                if (!(Regex.IsMatch(car.BootSpace.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    throw new CarException("Bootspace should be a number with 3 digits");
                }
                if (!(Regex.IsMatch(car.price.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Price should be a number");
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }


        public static bool AddCarBAL(Car car)
        {
            bool added = false;
            try
            {
                if (Validate(car))
                {

                    CarDAL dal = new CarDAL();
                    added = dal.AddCarDAL(car);

                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return added;
        }

        public static bool ModifyCarBAL(Car car)
        {
            bool modified = false;
            try
            {
                if (Validate(car))
                {

                    CarDAL dal = new CarDAL();
                    modified = dal.ModifyCarDAL(car);

                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return modified;
        }

        public static Car SearchCarBAL(string model)
        {
            Car cd = new Car();
            try
            {
                CarDAL dal = new CarDAL();
                cd = dal.SearchCarDAL(model);

            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cd;
        }

        public static bool RemoveCarBAL(string model)
        {
            bool removed = false;
            try
            {

                CarDAL dal = new CarDAL();
                removed = dal.RemoveCarDAL(model);

            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return removed;
        }

        public static List<Car> ShowBAL()
        {
            try
            {
                CarDAL dal = new CarDAL();
                Carlist = dal.ShowDAL();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Carlist;
        }


    }
}
    



